import os
import sys
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from config.env_loader import load_env

import psycopg2
from psycopg2.extras import execute_values

# On réutilise tes infos DB et fonctions existantes
from functions.weather_functions import (
    get_airport_from_postgres_byAirPortCode,
    fetch_hourly_series,
)


load_env()

# Connexion DB : on réutilise ton style PG_CONN_INFO s'il existe, sinon variables d'env
PG_CONN_INFO = {
    "host":     os.getenv("PG_HOST", "localhost"),
    "port":     int(os.getenv("PG_PORT", "5432")),
    "dbname":   os.getenv("PG_DB", "airline"),
    "user":     os.getenv("PG_USER", "dst_user"),
    "password": os.getenv("PG_PASSWORD", "dst_password"),
}


def getenv_int(name: str, default: int) -> int:
    val = os.getenv(name)
    if val is None or val == "":
        return default
    try:
        return int(val)
    except ValueError:
        print(f"[warn] {name} invalide: {val!r} → fallback {default}")
        return default

OWM_DAILY_BUDGET = getenv_int("OWM_DAILY_BUDGET", 900)

def _pairs_to_prefill_for_date(cur, target_date):
    """
    Retourne un set {(iata, day_local_date)} à pré-remplir pour:
      - départs SANS météo, ce jour
      - arrivées SANS météo, ce jour
    """
    pairs = set()

    # Départs
    cur.execute(
        """
        SELECT DISTINCT a.iata_code AS iata,
               date_trunc('day',
                 make_timestamptz(
                   EXTRACT(YEAR  FROM lfh.departure_schedule_date)::int,
                   EXTRACT(MONTH FROM lfh.departure_schedule_date)::int,
                   EXTRACT(DAY   FROM lfh.departure_schedule_date)::int,
                   0,0,0,
                   a.timezone
                 )::timestamptz
               ) AS day_local
        FROM lufthansa_flight_history lfh
        JOIN routes r   ON r.id = lfh.route_id
        JOIN airports a ON a.iata_code = r.departure_airport
        WHERE lfh.depart_airport_meteo IS NULL
          AND lfh.departure_schedule_date = %s
        """,
        (target_date,)
    )
    for iata, day_local in cur.fetchall():
        pairs.add((iata, day_local))

    # Arrivées
    cur.execute(
        """
        SELECT DISTINCT a.iata_code AS iata,
               date_trunc('day',
                 make_timestamptz(
                   EXTRACT(YEAR  FROM lfh.arrival_schedule_date)::int,
                   EXTRACT(MONTH FROM lfh.arrival_schedule_date)::int,
                   EXTRACT(DAY   FROM lfh.arrival_schedule_date)::int,
                   0,0,0,
                   a.timezone
                 )::timestamptz
               ) AS day_local
        FROM lufthansa_flight_history lfh
        JOIN routes r   ON r.id = lfh.route_id
        JOIN airports a ON a.iata_code = r.arrival_airport
        WHERE lfh.arr_airport_meteo IS NULL
          AND lfh.arrival_schedule_date = %s
        """,
        (target_date,)
    )
    for iata, day_local in cur.fetchall():
        pairs.add((iata, day_local))

    return pairs


def _prefill_cache_one_airport_one_day(cur, iata: str, day_local_ts):
    """
    Insère dans weather_hourly_cache toutes les heures de day_local (heure locale aéroport)
    à partir d'UN seul appel OWM. Retourne le nombre de lignes insérées.
    """
    ap = get_airport_from_postgres_byAirPortCode(iata)
    if not ap:
        return 0

    lat, lon, tz = ap["lat"], ap["lon"], ap["timezone"] or "UTC"
    series = fetch_hourly_series(lat, lon, lang="fr")
    if series is None:
        return 0

    tzinfo = ZoneInfo(tz)
    start = day_local_ts.astimezone(tzinfo).replace(hour=0, minute=0, second=0, microsecond=0)
    end   = start + timedelta(days=1)

    rows = []
    for p in series:
        dt_utc = p["_dt_utc"]               # datetime aware UTC (ajouté par fetch_hourly_series)
        dt_loc = dt_utc.astimezone(tzinfo)
        if not (start <= dt_loc < end):
            continue
        bucket = dt_loc.replace(minute=0, second=0, microsecond=0)
        payload = {
            "datetime": p["datetime"],
            "temperature": p["temperature"],
            "wind_speed": p["wind_speed"],
            "visibility": p["visibility"],
            "conditions": p["conditions"],
        }
        rows.append((iata, bucket, payload, "owm"))

    if not rows:
        return 0

    # INSERT ... ON CONFLICT DO NOTHING en bulk
    execute_values(
        cur,
        """
        INSERT INTO weather_hourly_cache(airport_iata, bucket_local, payload, source)
        VALUES %s
        ON CONFLICT (airport_iata, bucket_local) DO NOTHING
        """,
        rows,
        template="(%s,%s,%s::jsonb,%s)"
    )
    return cur.rowcount or 0


def _update_departures_from_cache(cur, target_date):
    cur.execute(
        """
        WITH dep_buckets AS (
          SELECT
            lfh.id,
            r.departure_airport AS dep_iata,
            (
              make_timestamptz(
                EXTRACT(YEAR  FROM lfh.departure_schedule_date)::int,
                EXTRACT(MONTH FROM lfh.departure_schedule_date)::int,
                EXTRACT(DAY   FROM lfh.departure_schedule_date)::int,
                EXTRACT(HOUR  FROM lfh.departure_schedule_time)::int,
                0, 0,
                a.timezone
              )
            )::timestamptz AS dep_bucket_local
          FROM lufthansa_flight_history lfh
          JOIN routes   r ON r.id = lfh.route_id
          JOIN airports a ON a.iata_code = r.departure_airport
          WHERE lfh.depart_airport_meteo IS NULL
            AND lfh.departure_schedule_date = %s
        )
        UPDATE lufthansa_flight_history lfh
        SET depart_airport_meteo = c.payload
        FROM dep_buckets b
        JOIN weather_hourly_cache c
          ON c.airport_iata = b.dep_iata
         AND c.bucket_local = b.dep_bucket_local
        WHERE lfh.id = b.id
          AND lfh.depart_airport_meteo IS NULL
        """,
        (target_date,)
    )


def _update_arrivals_from_cache(cur, target_date):
    cur.execute(
        """
        WITH arr_buckets AS (
          SELECT
            lfh.id,
            r.arrival_airport AS arr_iata,
            (
              make_timestamptz(
                EXTRACT(YEAR  FROM lfh.arrival_schedule_date)::int,
                EXTRACT(MONTH FROM lfh.arrival_schedule_date)::int,
                EXTRACT(DAY   FROM lfh.arrival_schedule_date)::int,
                EXTRACT(HOUR  FROM lfh.arrival_schedule_time)::int,
                0, 0,
                a.timezone
              )
            )::timestamptz AS arr_bucket_local
          FROM lufthansa_flight_history lfh
          JOIN routes   r ON r.id = lfh.route_id
          JOIN airports a ON a.iata_code = r.arrival_airport
          WHERE lfh.arr_airport_meteo IS NULL
            AND lfh.arrival_schedule_date = %s
        )
        UPDATE lufthansa_flight_history lfh
        SET arr_airport_meteo = c.payload
        FROM arr_buckets b
        JOIN weather_hourly_cache c
          ON c.airport_iata = b.arr_iata
         AND c.bucket_local = b.arr_bucket_local
        WHERE lfh.id = b.id
          AND lfh.arr_airport_meteo IS NULL
        """,
        (target_date,)
    )


def enrich_weather_for_date(target_date_str: str, daily_budget: int = OWM_DAILY_BUDGET):
    target_date = datetime.fromisoformat(target_date_str).date()

    with psycopg2.connect(**PG_CONN_INFO) as conn:
        conn.autocommit = False
        with conn.cursor() as cur:
            pairs = _pairs_to_prefill_for_date(cur, target_date)

            owm_calls = 0
            for iata, day_local_ts in pairs:
                if owm_calls >= daily_budget:
                    print(f"[weather] Budget OWM atteint ({daily_budget}). Stop.")
                    break
                inserted = _prefill_cache_one_airport_one_day(cur, iata, day_local_ts)
                # On compte un appel par aéroport-jour (même si 0 insert suite à conflit)
                owm_calls += 1
            # commit des insertions cache
            conn.commit()

            # UPDATE vols depuis le cache
            _update_departures_from_cache(cur, target_date)
            _update_arrivals_from_cache(cur, target_date)
            conn.commit()

    print(f"[weather] Enrichissement programmé terminé pour {target_date_str}.")

if __name__ == "__main__":
    # Usage:
    #   python scripts/enrich_weather_programmed.py 2025-09-28
    # ou sans argument => aujourd'hui
    if len(sys.argv) >= 2:
        d = sys.argv[1]
    else:
        d = datetime.today().date().isoformat()
    enrich_weather_for_date(d, daily_budget=OWM_DAILY_BUDGET)
