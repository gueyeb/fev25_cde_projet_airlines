from functions.pg_functions import getImportantRoutes
from functions.pg_functions import insert_dataframe, date
from functions.utils_functions import fetch_schedules, _safe_get, _parse_sched_datetime, cached_weather
from functions.utils_functions import get_airport_from_postgres_byAirPortCode_cached


def sync_lufthansa_flight_history():
    """
    Récupère les vols du jour sur les routes importantes (aller/retour),
    et insère 1 ligne par SEGMENT de vol dans lufthansa_flight_history.

    Points clés :
      - Itère Schedule[] puis Flight[] (segments).
      - Utilise les codes aéroports du segment (ex. ZRH, FRA, ...), pas seulement la route globale.
      - Météo calculée au niveau segment, timezone issue de la table airports.
      - Colonnes JSONB : depart_airport_meteo / arr_airport_meteo.
      - Déduplication locale + contrainte unique en base :
        (marketing_carrier_airline_id, marketing_carrier_flight_number, departure_schedule_date).
    """
    today = date.today().isoformat()
    routes = getImportantRoutes(today)  # DataFrame: id, departure_airport, arrival_airport, ...
    all_rows = []

    for _, route in routes.iterrows():
        route_dep = route["departure_airport"]
        route_arr = route["arrival_airport"]

        # Explorer les deux sens (A: sens "normal", R: sens inverse)
        for test_dep, test_arr in [(route_dep, route_arr), (route_arr, route_dep)]:
            sens = "A" if test_dep == route_dep else "R"
            endpoint = f"/operations/schedules/{test_dep}/{test_arr}/{today}"

            try:
                data = fetch_schedules(endpoint, "ScheduleResource.Schedule")
                if not data:
                    continue

                # D'après le JSON fourni : ScheduleResource.Schedule est une LISTE
                schedules = data if isinstance(data, list) else [data]

                for sched in schedules:
                    total_journey = _safe_get(sched, "TotalJourney", "Duration")
                    segs = _safe_get(sched, "Flight")
                    if not segs:
                        continue
                    if isinstance(segs, dict):  # normaliser en liste
                        segs = [segs]

                    for seg in segs:
                        # --- Aéroports du SEGMENT (et non pas la route globale) ---
                        dep_iata_seg = _safe_get(seg, "Departure", "AirportCode")
                        arr_iata_seg = _safe_get(seg, "Arrival",   "AirportCode")

                        # --- Infos marketing / équipement au niveau segment ---
                        marketing = _safe_get(seg, "MarketingCarrier", default={}) or {}
                        equipment = _safe_get(seg, "Equipment", default={}) or {}

                        airline_id    = marketing.get("AirlineID")
                        flight_number = marketing.get("FlightNumber")
                        aircraft_code = equipment.get("AircraftCode")

                        # --- Horaires programmés du segment ---
                        dep_date, dep_time, dep_dt, arr_date, arr_time, arr_dt = _parse_sched_datetime(seg)

                        # --- Terminaux (si présents) ---
                        dep_terminal = _safe_get(seg, "Departure", "Terminal", "Name")
                        arr_terminal = _safe_get(seg, "Arrival",   "Terminal", "Name")

                        # --- Météo au niveau SEGMENT (coords + timezone via airports) ---
                        dep_info = get_airport_from_postgres_byAirPortCode_cached(dep_iata_seg) if dep_iata_seg else None
                        arr_info = get_airport_from_postgres_byAirPortCode_cached(arr_iata_seg) if arr_iata_seg else None

                        if dep_dt and dep_info:
                            dep_bucket = dep_dt.replace(minute=0, second=0, microsecond=0).isoformat()
                            departure_airport_weather = cached_weather(
                                dep_iata_seg, dep_info["lat"], dep_info["lon"], dep_bucket, dep_info.get("timezone")
                            )
                        else:
                            departure_airport_weather = None

                        if arr_dt and arr_info:
                            arr_bucket = arr_dt.replace(minute=0, second=0, microsecond=0).isoformat()
                            arrival_airport_weather = cached_weather(
                                arr_iata_seg, arr_info["lat"], arr_info["lon"], arr_bucket, arr_info.get("timezone")
                            )
                        else:
                            arrival_airport_weather = None

                        # --- Construction de la ligne à insérer ---
                        row = {
                            "total_journey_duration": total_journey,  # duplique par segment : ok
                            "route_id": route["id"],
                            "route_sens": sens,
                            "departure_schedule_date": dep_date,
                            "departure_schedule_time": dep_time,
                            "departure_terminal": dep_terminal,
                            "arrival_schedule_date": arr_date,
                            "arrival_schedule_time": arr_time,
                            "arrival_terminal": arr_terminal,
                            "marketing_carrier_airline_id": airline_id,
                            "marketing_carrier_flight_number": flight_number,
                            "equipment_aircraft_code": aircraft_code,
                            # JSONB
                            "depart_airport_meteo": departure_airport_weather,
                            "arr_airport_meteo": arrival_airport_weather,
                        }

                        # Respecter la contrainte unique en base
                        if airline_id and flight_number and dep_date:
                            all_rows.append(row)

            except Exception as e:
                print(f"❌ Erreur API pour {test_dep}->{test_arr} : {e}")

    # Insert en bloc
    if all_rows:
        import pandas as pd
        df = pd.DataFrame(all_rows)

        # Déduplication soft côté client
        df.drop_duplicates(
            subset=[
                "marketing_carrier_airline_id",
                "marketing_carrier_flight_number",
                "departure_schedule_date",
            ],
            inplace=True,
        )
        insert_dataframe(df, "lufthansa_flight_history")
        print(f"✅ Insert lufthansa_flight_history : {len(df)} ligne(s)")
    else:
        print("📭 Aucun segment à insérer pour aujourd'hui.")


if __name__ == "__main__":
    sync_lufthansa_flight_history()