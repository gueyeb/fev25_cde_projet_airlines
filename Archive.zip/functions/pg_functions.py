import os
from datetime import date

import pandas as pd
from sqlalchemy import Table, MetaData
from sqlalchemy import create_engine
from sqlalchemy import text
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.exc import IntegrityError
from typing import Iterable
from sqlalchemy import MetaData, Table
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.exc import IntegrityError
from contextlib import contextmanager

from config.env_loader import load_env

load_env()


FK_VIOLATION_CODE = "23503"

HOST = os.getenv("PG_HOST")
PORT = int(os.getenv("PG_PORT"))
DBNAME = os.getenv("PG_DB")
USER = os.getenv("PG_USER")
PASSWORD = os.getenv("PG_PASSWORD")


# Connexion PostgreSQL
DB_URL = f"postgresql://{USER}:{PASSWORD}@{HOST}:{PORT}/{DBNAME}"
engine = create_engine(DB_URL)

# def insert_dataframe(df, table_name, batch_size=5000):
#     if df.empty:
#         print(f"Aucune donnée à insérer pour {table_name}")
#         return
#
#     metadata = MetaData()
#     table = Table(table_name, metadata, autoload_with=engine)
#
#     total_rows = len(df)
#     inserted = 0
#
#     print(f"\nInsertion par lots de {batch_size} lignes dans {table_name}...\n")
#
#     for start in range(0, total_rows, batch_size):
#         end = start + batch_size
#         batch = df.iloc[start:end].to_dict(orient='records')
#
#         try:
#             stmt = pg_insert(table).values(batch)
#             stmt = stmt.on_conflict_do_nothing()
#             with engine.begin() as conn:
#                 conn.execute(stmt)
#             inserted += len(batch)
#             print(f"✔️ Lignes {start+1} à {min(end, total_rows)} traitées (doublons ignorés)")
#         except IntegrityError as e:
#             print(f"⚠️ Erreur lors de l’insertion des lignes {start+1} à {min(end, total_rows)} : {e}")
#
#     print(f"✅ {inserted} lignes traitées dans {table_name}")


@contextmanager
def _begin_conn(engine):
    """Contexte pratique pour obtenir une connexion et un begin() explicite."""
    with engine.connect() as conn:
        with conn.begin():
            yield conn

def _is_fk_violation(err: IntegrityError) -> bool:
    """Détermine si l'erreur est une violation de clé étrangère (SQLSTATE 23503)."""
    # SQLAlchemy -> .orig peut être une exception psycopg2/psycopg3
    orig = getattr(err, "orig", None)
    # psycopg3: orig.sqlstate ; psycopg2: orig.pgcode
    code = getattr(orig, "sqlstate", None) or getattr(orig, "pgcode", None)
    return code == FK_VIOLATION_CODE

def _progress(start_idx: int, end_idx: int, total: int, msg: str):
    print(f"{msg}  ({start_idx+1}–{end_idx} / {total})")

def insert_dataframe(df, table_name, batch_size: int = 5000):
    if df.empty:
        print(f"Aucune donnée à insérer pour {table_name}")
        return

    metadata = MetaData()
    table = Table(table_name, metadata, autoload_with=engine)

    total_rows = len(df)
    inserted_ok = 0
    skipped_fk = 0

    print(f"\nInsertion par lots de {batch_size} lignes dans {table_name}...\n")

    # 1) Chemin rapide: tentative par lot
    for start in range(0, total_rows, batch_size):
        end = min(start + batch_size, total_rows)
        batch = df.iloc[start:end].to_dict(orient="records")

        try:
            stmt = pg_insert(table).values(batch).on_conflict_do_nothing()
            with _begin_conn(engine) as conn:
                conn.execute(stmt)
            inserted_ok += len(batch)
            _progress(start, end, total_rows, "✔️ Lot traité (doublons ignorés)")
        except IntegrityError as e:
            # Si ce n'est PAS une FK violation, on log et continue en repli ligne à ligne quand même.
            print(f"⚠️ Conflit d'intégrité sur le lot {start+1}–{end} : {e}. "
                  f"Repli en insertion ligne à ligne avec SAVEPOINT…")

            # 2) Repli sélectif: ligne par ligne avec SAVEPOINT
            with engine.connect() as conn:
                # On gère manuellement les transactions pour pouvoir utiliser des SAVEPOINTs.
                trans = conn.begin()
                try:
                    # Préparer le statement une seule fois pour performance
                    base_stmt = pg_insert(table).on_conflict_do_nothing()

                    for i, row in enumerate(batch, start=start):
                        savepoint = conn.begin_nested()  # crée un SAVEPOINT
                        try:
                            conn.execute(base_stmt.values(row))
                            inserted_ok += 1
                        except IntegrityError as row_err:
                            if _is_fk_violation(row_err):
                                skipped_fk += 1
                                print(f"   ↳ ⏭️ Ligne {i+1} ignorée (ForeignKeyViolation 23503)")
                            else:
                                # Autre violation: on ignore aussi cette ligne mais on l’indique.
                                print(f"   ↳ ⏭️ Ligne {i+1} ignorée (IntegrityError: {row_err})")
                            # rollback au SAVEPOINT pour annuler uniquement cette ligne
                            savepoint.rollback()
                        else:
                            savepoint.commit()
                    trans.commit()
                except Exception as fatal:
                    trans.rollback()
                    print(f"❌ Erreur inattendue lors du repli ligne à ligne: {fatal}")

    print(f"✅ Traitement terminé pour {table_name} :")
    print(f"   - Lignes insérées/traitées (hors doublons) : {inserted_ok}")
    print(f"   - Lignes ignorées pour ForeignKeyViolation : {skipped_fk}")

def getImportantRoutes(target_date=None):
    if target_date is None:
        target_date = date.today()

    query = """
    SELECT r.id, r.departure_airport, r.arrival_airport
    FROM routes r
    WHERE important = TRUE
      AND NOT EXISTS (
        SELECT 1
        FROM lufthansa_flight_history f
        WHERE f.route_id = r.id
          AND f.departure_schedule_date = %(date)s
      )
    """

    return pd.read_sql(query, con=engine, params={"date": target_date})


def getAllImportantRoutes():
    query = text("""
        SELECT id, departure_airport, arrival_airport
        FROM routes
        WHERE important = TRUE
    """)
    return pd.read_sql(query, con=engine)


def getAllLufthansaFlightHistory():
    query = """
    SELECT * FROM lufthansa_flight_history
    """
    return pd.read_sql(query, con=engine)

def getFlightsToUpdateToday():
    """
    Retourne les vols dont l'arrivée planifiée est aujourd'hui ET qui n'ont pas encore été rafraîchis.
    """
    query = """
    SELECT *
    FROM lufthansa_flight_history
    WHERE arrival_schedule_date = CURRENT_DATE
      AND actuals_refreshed = false
    """
    return pd.read_sql(query, con=engine)

def get_route_airports(route_id: int):
    """
    Retourne (departure_airport, arrival_airport) pour une route donnée.
    Suppose table routes(id, departure_airport, arrival_airport).
    """
    query = """
        SELECT departure_airport, arrival_airport
        FROM routes
        WHERE id = :rid
        LIMIT 1
    """
    with engine.connect() as conn:
        row = conn.execute(text(query), {"rid": route_id}).fetchone()
        if row:
            return row[0], row[1]
    return None, None

def city_exists(code):
    """Vérifie si une ville existe déjà dans la table cities"""
    if not code:
        return False
    with engine.connect() as conn:
        result = conn.execute(text("SELECT 1 FROM cities WHERE city_code = :code"), {"code": code})
        return result.fetchone() is not None


def getAirPorts():
    query = """
    SELECT iata_code, latitude, longitude 
    FROM airports 
    WHERE location_type = 'Airport' 
    AND latitude IS NOT NULL AND longitude IS NOT NULL
    """
    return pd.read_sql(query, engine)

def ensure_airline_exists(airline_code):
    with engine.connect() as conn:
        result = conn.execute(
            text("SELECT 1 FROM airlines WHERE airline_code = :code LIMIT 1"),
            {"code": airline_code}
        ).fetchone()

    if not result:
        with engine.begin() as conn:
            conn.execute(
                text("INSERT INTO airlines (airline_code) VALUES (:code)"),
                {"code": airline_code}
            )

def ensure_aircraft_exists(aircraft_code):
    if not aircraft_code:
        return

    with engine.connect() as conn:
        result = conn.execute(
            text("SELECT 1 FROM aircrafts WHERE aircraft_code = :code LIMIT 1"),
            {"code": aircraft_code}
        ).fetchone()

    if not result:
        with engine.begin() as conn:
            conn.execute(
                text("INSERT INTO aircrafts (aircraft_code) VALUES (:code)"),
                {"code": aircraft_code}
            )

def table_count(table_name: str) -> int:
    q = text(f"SELECT COUNT(*) FROM {table_name}")
    with engine.connect() as conn:
        return int(conn.execute(q).scalar() or 0)